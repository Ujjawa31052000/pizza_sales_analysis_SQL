-- determine the no. of order by hour of the day
SELECT 
    HOUR(order_time) AS hour, COUNT(order_id) AS order_count
FROM
    pizza_order
GROUP BY HOUR(order_time);
